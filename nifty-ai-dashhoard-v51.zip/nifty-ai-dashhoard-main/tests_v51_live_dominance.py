"""
tests_v51_live_dominance.py -- v51: side-aware calibration + live-dominance relief + opening-reversal exception.
Run:  python -m unittest tests_v51_live_dominance -v
"""
import os, sys, json, sqlite3, unittest
from datetime import datetime, time as dtime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tests_edge_v36 import DbCase, _flags, _strategy  # noqa: E402  (also installs the import stubs)
from tests_v42_momentum_tick import _strong           # noqa: E402
import macro_confluence as mc
import trade_learning as tl
import ai_trade_decision as atd

GR_STRONG_SELL = {"status": "AVAILABLE", "directional_bias": "SELL", "strength": "STRONG"}


def _seed(direction, wins, losses, with_side=True):
    c = sqlite3.connect(tl.DB_NAME)
    feats = {"is_buy": 1.0 if direction == "BUY" else 0.0, "rr": 1.7}
    for i in range(wins + losses):
        extra = {"_entry_meta": {"logic_version": tl.LOGIC_VERSION, "side": direction}}
        if with_side:
            extra["_features"] = feats
        c.execute("INSERT INTO ai_trade_setups (timestamp,direction,strike,option_type,underlying_entry,stop_loss,target,confidence_pct,factors_json,status)"
                  " VALUES ('2026-01-01 10:00:00',?,1,'CE',1,1,1,1,?,?)", (direction, json.dumps(_flags(8 + i % 4, **extra)), "WIN" if i < wins else "LOSS"))
    c.commit(); c.close()


def _decide(direction="BUY", now=dtime(11, 0), macro_kind="aligned", strategy=None, transition=False, live=24000.0, atr=14.0):
    """macro_kind: aligned | neutral | opposed | strong_opposed  (changes only the macro inputs, not the live tape)."""
    bull = direction == "BUY"
    sr = {"status": "OK", "location": "AT_SUPPORT" if bull else "AT_RESISTANCE",
          "confirmation": {"support_rejection_confirmed": True, "resistance_rejection_confirmed": True,
                           "bullish_trend_transition_confirmed": bool(transition and bull),
                           "bearish_trend_transition_confirmed": bool(transition and not bull)},
          "entry_timing": {}, "major_support": {"price": live - 2, "low": live - 6, "high": live - 1, "sources": ["PDL"]},
          "major_resistance": {"price": live + 2, "low": live + 1, "high": live + 6, "sources": ["PDH"]}}
    ctx = {"Data Freshness": "Live / fresh", "RAW Regime Engine": "BULLISH" if bull else "BEARISH",
           "RAW Multi-Timeframe Structure": ("bullish bullish bullish" if bull else "bearish bearish bearish"),
           "RAW Order Flow": {"pressure": "BUYING PRESSURE" if bull else "SELLING PRESSURE"}}
    lp = {"status": "APPROACHING_LEVEL", "approaching": "support" if bull else "resistance", "level_price": live - 1 if bull else live + 1,
          "distance_pts": 1.0, "break_pct": 70, "bounce_pct": 72, "directional_bias": "Bullish" if bull else "Bearish",
          "factors": ["Heavy Put OI" if bull else "Heavy Call OI", "above a rising VWAP" if bull else "below a falling VWAP"]}
    # macro inputs
    sgn = 1 if bull else -1
    if macro_kind == "aligned":
        gr, gavg, news, adv = None, 0.4 * sgn, "BULLISH" if bull else "BEARISH", (35, 15) if bull else (12, 38)
    elif macro_kind == "neutral":
        gr, gavg, news, adv = None, 0.0, "NEUTRAL", (25, 25)
    elif macro_kind == "opposed":
        gr, gavg, news, adv = None, -0.4 * sgn, "BEARISH" if bull else "BULLISH", (12, 38) if bull else (35, 15)
    else:   # strong_opposed
        gr = {"status": "AVAILABLE", "directional_bias": "SELL" if bull else "BUY", "strength": "STRONG"}
        gavg, news, adv = -0.6 * sgn, "BEARISH" if bull else "BULLISH", (8, 42) if bull else (42, 8)
    return atd.generate_trade_decision(
        live_price=live, level_prediction=lp, atr=atr, max_pain=23900 if bull else 24100, signal_code=sgn, ml_agrees=True,
        breadth_advances=adv[0], breadth_declines=adv[1],
        global_avg_change=gavg, live_vix=13.0, india_news_sentiment=news, level_ladder=None, sr_context=sr, sniper_bias="BULLISH" if bull else "BEARISH",
        is_choppy=False, dashboard_context=ctx, global_research=gr, nifty50_news_sentiment=news, nifty50_fundamentals_bias="NEUTRAL",
        strategy_result=strategy or _strong(direction, live=60), raw_option_chain=None, now_ist=datetime(2026, 10, 5, now.hour, now.minute))


class SideAwareCalibration(DbCase):
    def test_buy_is_not_dragged_down_by_a_losing_sell_record(self):
        _seed("SELL", wins=15, losses=45)                       # 25 % SELL record, 60 trades
        out = _decide("BUY")
        self.assertTrue(out["has_setup"], out.get("reason"))
        self.assertGreaterEqual(out["win_probability"], 0.40)

    def test_sell_is_still_judged_by_its_own_losing_record(self):
        _seed("SELL", wins=6, losses=54)                        # 10 % SELL record
        out = _decide("SELL")
        self.assertFalse(out["has_setup"])
        self.assertIn("edge", out["reason"].lower())

    def test_buy_with_its_own_losing_record_is_still_stopped(self):
        _seed("BUY", wins=3, losses=37)
        self.assertFalse(_decide("BUY")["has_setup"])

    def test_kill_switch_restores_the_old_shared_win_rate(self):
        _seed("SELL", wins=15, losses=45)
        tl.SIDE_AWARE_CALIBRATION = False
        self.addCleanup(setattr, tl, "SIDE_AWARE_CALIBRATION", True)
        self.assertFalse(_decide("BUY")["has_setup"])

    def test_rows_without_side_info_count_for_both_sides(self):
        _seed("BUY", wins=3, losses=37, with_side=False)        # legacy rows: side unknown
        self.assertFalse(_decide("BUY")["has_setup"])
        self.assertFalse(_decide("SELL")["has_setup"])


class LiveDominanceRelief(DbCase):
    """History = a losing SELL record only (a BUY has no record of its own yet) -- the 26-Oct situation."""
    def setUp(self):
        super().setUp()
        _seed("SELL", wins=15, losses=45)
        self.strong = _strong("BUY", live=60, cons=100, n=5)

    def test_opposed_macro_no_longer_kills_a_trend_the_live_tape_confirms(self):
        atd.LIVE_DOMINANCE_RELIEF = False
        self.addCleanup(setattr, atd, "LIVE_DOMINANCE_RELIEF", True)
        old = _decide("BUY", macro_kind="opposed", strategy=self.strong)
        self.assertFalse(old["has_setup"])                        # v50: blocked (+0.13R < bar)
        atd.LIVE_DOMINANCE_RELIEF = True
        new = _decide("BUY", macro_kind="opposed", strategy=self.strong)
        self.assertTrue(new["has_setup"], new.get("reason"))      # v51: live tape outvotes stale global/breadth
        self.assertTrue(new["momentum_lane"])
        self.assertTrue(new["factor_flags"]["_live_dominance"]["relief_used"])

    def test_strong_opposed_macro_still_gets_no_relief(self):
        out = _decide("BUY", macro_kind="strong_opposed", strategy=self.strong)
        self.assertFalse(out["has_setup"])

    def test_relief_needs_real_live_dominance(self):
        weak = _decide("BUY", macro_kind="opposed", strategy=_strong("BUY", live=20))
        self.assertFalse(weak["has_setup"])
        few = _decide("BUY", macro_kind="opposed", strategy=_strong("BUY", live=60, cons=100, n=2))
        self.assertFalse(few["has_setup"])

    def test_relief_cannot_rescue_a_real_losing_record_of_the_same_side(self):
        _seed("BUY", wins=2, losses=38)
        self.assertFalse(_decide("BUY", macro_kind="opposed", strategy=self.strong)["has_setup"])


class OpeningReversalException(DbCase):
    def test_turned_structure_plus_live_dominance_may_trade_before_0945(self):
        out = _decide("BUY", now=dtime(9, 35), macro_kind="neutral", transition=True, strategy=_strong("BUY", live=60, cons=100, n=5))
        self.assertTrue(out["has_setup"], out.get("reason"))
        self.assertTrue(out["factor_flags"]["_live_dominance"]["opening_exception"])

    def test_no_turn_confirmation_means_the_old_opening_rule_holds(self):
        out = _decide("BUY", now=dtime(9, 35), macro_kind="neutral", transition=False, strategy=_strong("BUY", live=60, cons=100, n=5))
        self.assertFalse(out["has_setup"]); self.assertIn("Opening range forming", out["reason"])

    def test_opposed_macro_keeps_the_opening_rule(self):
        out = _decide("BUY", now=dtime(9, 35), macro_kind="opposed", transition=True, strategy=_strong("BUY", live=60, cons=100, n=5))
        self.assertFalse(out["has_setup"]); self.assertIn("Opening range forming", out["reason"])

    def test_kill_switch(self):
        atd.OPENING_LIVE_EXCEPTION = False
        self.addCleanup(setattr, atd, "OPENING_LIVE_EXCEPTION", True)
        out = _decide("BUY", now=dtime(9, 35), macro_kind="neutral", transition=True, strategy=_strong("BUY", live=60, cons=100, n=5))
        self.assertFalse(out["has_setup"]); self.assertIn("Opening range forming", out["reason"])


class EarlyGlobalVetoRelief(DbCase):
    def _sell(self, live, n=3):
        g = {"status": "AVAILABLE", "directional_bias": "BUY", "strength": "STRONG"}
        from tests_edge_v36 import _decide as base
        return base("SELL", strategy=_strong("SELL", live=live, cons=60, n=n), global_research=g, macro=True)

    def test_veto_steps_aside_once_the_tape_has_started_to_move(self):
        out = self._sell(live=30)       # score 30 < lane's 45 and consensus 60 < 80 -> v50b blocked here
        self.assertNotIn("Global research is STRONGLY", out.get("reason", ""))

    def test_veto_still_blocks_when_the_tape_is_flat(self):
        out = self._sell(live=15)
        self.assertFalse(out["has_setup"]); self.assertIn("Global research is STRONGLY BUY", out["reason"])

    def test_kill_switch(self):
        atd.GLOBAL_VETO_EARLY_RELIEF = False
        self.addCleanup(setattr, atd, "GLOBAL_VETO_EARLY_RELIEF", True)
        out = self._sell(live=30)
        self.assertFalse(out["has_setup"]); self.assertIn("Global research is STRONGLY BUY", out["reason"])


if __name__ == "__main__":
    unittest.main()
