from app_logging import get_logger
logger = get_logger(__name__)
import pandas as pd
import numpy as np

# Naya Google GenAI Package Import (google-genai SDK)
try:
    from google import genai
    HAS_GENAI = True
except ImportError:
    genai = None
    HAS_GENAI = False

def _is_quota_error(exc: Exception) -> bool:
    """Detects a rate-limit / quota-exhausted error from the Gemini API so we
    know it's worth rotating to the next key, instead of treating every
    error the same (a bad prompt should not burn through all 5 keys)."""
    text = str(exc).lower()
    quota_signals = ["429", "quota", "rate limit", "resource_exhausted", "resource exhausted"]
    return any(sig in text for sig in quota_signals)


class HybridAIEngine:
    """
    Institutional Grade Hybrid AI Logic Engine for Nifty 50 Real-Time Trading.
    Upgraded with Multi-Factor Confluence, Fake Breakout Guards, and Advanced Risk Architecture.
    """

    def __init__(self, api_key=None, api_keys=None):
        """Accepts either a single api_key (old callers) or a list of
        api_keys (new, rotates through them so one exhausted key doesn't
        kill the whole Deep Reasoning Report)."""
        if api_keys:
            self.api_keys = [k for k in api_keys if k]
        elif api_key:
            self.api_keys = [api_key]
        else:
            self.api_keys = []
        self.client = None
        if self.api_keys and HAS_GENAI:
            try:
                self.client = genai.Client(api_key=self.api_keys[0])  # kept for any code checking `.client`
            except Exception:
                logger.exception("Broad exception caught; fallback path executed")
                pass

    def calculate_technical_score(self, live_price, df, df_option_chain):
        if df is None or df.empty:
            return 0.0, {'rsi': 50, 'macd': 0, 'ema_20': live_price, 'ema_50': live_price, 'vwap': live_price, 'atr': 15.0, 'avg_pcr': 1.0}

        latest = df.iloc[-1]
        rsi = float(latest.get('RSI', 50))
        macd = float(latest.get('MACD', 0))
        ema_20 = float(latest.get('EMA_20', live_price))
        ema_50 = float(latest.get('EMA_50', live_price))
        vwap = float(latest.get('VWAP', live_price))
        atr = float(latest.get('ATR', 15.0))

        score = 0.0

        # RSI Momentum Confluence
        if rsi > 60: score += 0.25
        elif rsi < 40: score -= 0.25
        elif rsi > 50: score += 0.1
        else: score -= 0.1

        # Trend & VWAP Confirmation
        if live_price > vwap and live_price > ema_20 > ema_50: score += 0.40
        elif live_price < vwap and live_price < ema_20 < ema_50: score -= 0.40
        elif live_price > ema_20: score += 0.15
        elif live_price < ema_20: score -= 0.15

        # MACD Histogram Momentum
        if macd > 0: score += 0.15
        else: score -= 0.15

        # Option Chain PCR Confluence
        avg_pcr = 1.0
        if df_option_chain is not None and not df_option_chain.empty and 'PCR' in df_option_chain.columns:
            try:
                # Standard PCR = total Put OI / total Call OI. The old plain mean of the per-strike PCR column was blown up by
                # strikes with near-zero Call OI (reports showed PCR ~797) and always pushed the score bullish.
                if {'Put OI', 'Call OI'}.issubset(df_option_chain.columns) and float(df_option_chain['Call OI'].sum()) > 0:
                    avg_pcr = float(df_option_chain['Put OI'].sum()) / float(df_option_chain['Call OI'].sum())
                else:
                    avg_pcr = float(df_option_chain['PCR'].median())
            except Exception:
                        logger.exception("Could not parse PCR; using neutral fallback")
                        avg_pcr = 1.0

        if avg_pcr > 1.25: score += 0.25
        elif avg_pcr > 1.05: score += 0.10
        elif avg_pcr < 0.75: score -= 0.25
        elif avg_pcr < 0.95: score -= 0.10

        tech_score = max(-1.0, min(1.0, score))
        metrics = {
            'rsi': rsi, 'macd': macd, 'ema_20': ema_20, 'ema_50': ema_50, 
            'vwap': vwap, 'atr': atr if atr > 0 else 15.0, 'avg_pcr': avg_pcr
        }
        return tech_score, metrics

    def calculate_smc_score(self, smc_data):
        if not smc_data: return 0.0, "Neutral Structure"
        event = str(smc_data).lower()
        score = 0.0
        if 'bos - bullish' in event or 'bullish continuation' in event: score += 0.85
        elif 'choch - bullish' in event or 'bullish reversal' in event: score += 0.95
        elif 'bos - bearish' in event or 'bearish continuation' in event: score -= 0.85
        elif 'choch - bearish' in event or 'bearish reversal' in event: score -= 0.95
        elif 'bullish' in event: score += 0.45
        elif 'bearish' in event: score -= 0.45
        return max(-1.0, min(1.0, score)), smc_data

    def calculate_macro_score(self, global_avg_change, sentiment_score):
        score = 0.0
        if global_avg_change <= -0.8: score -= 0.60
        elif global_avg_change <= -0.3: score -= 0.30
        elif global_avg_change >= 0.8: score += 0.60
        elif global_avg_change >= 0.3: score += 0.30

        sent = str(sentiment_score).lower()
        if 'strong bearish' in sent: score -= 0.40
        elif 'bearish' in sent: score -= 0.20
        elif 'strong bullish' in sent: score += 0.40
        elif 'bullish' in sent: score += 0.20
        return max(-1.0, min(1.0, score))

    def calculate_institutional_flow_score(self, fii_footprint, breadth_status, is_choppy, banknifty_correlation_note=None):
        score = 0.0
        fii_str = str(fii_footprint).upper()
        breadth_str = str(breadth_status).upper()

        # FII Footprint scoring
        if 'BULLISH' in fii_str: score += 0.50
        elif 'BEARISH' in fii_str: score -= 0.50

        # Internal Breadth scoring
        if 'STRONG' in breadth_str or 'POSITIVE' in breadth_str: score += 0.35
        elif 'WEAK' in breadth_str or 'NEGATIVE' in breadth_str: score -= 0.35

        # Bank Nifty vs Nifty divergence check -- Bank Nifty carries ~35%
        # effective weight in Nifty and a divergence between the two is a
        # well-known real-world fake breakout/breakdown warning signal.
        note = str(banknifty_correlation_note or "").upper()
        if "DIVERGENCE WARNING" in note:
            score *= 0.5  # sharply damp confidence when Bank Nifty disagrees
        elif "CONFIRMED" in note:
            score *= 1.1  # small boost when Bank Nifty confirms the move
            score = max(-1.0, min(1.0, score))

        # Choppy market penalty / override factor
        if is_choppy:
            score *= 0.15  # Heavy damping to eliminate false signals in chop zones

        return max(-1.0, min(1.0, score))

    def analyze(self, live_price, df, df_option_chain, smc_data, sentiment_score, global_avg_change, fii_footprint="Neutral", breadth_status="Neutral", is_choppy=False, banknifty_correlation_note=None, full_breadth_status=None, banknifty_sensex_data=None):
        tech_score, tech_metrics = self.calculate_technical_score(live_price, df, df_option_chain)
        smc_score, smc_desc = self.calculate_smc_score(smc_data)
        macro_score = self.calculate_macro_score(global_avg_change, sentiment_score)
        flow_score = self.calculate_institutional_flow_score(fii_footprint, breadth_status, is_choppy, banknifty_correlation_note)

        # Weighted institutional model matrix
        net_score = (tech_score * 0.20) + (smc_score * 0.25) + (macro_score * 0.15) + (flow_score * 0.40)
        
        if is_choppy:
            net_score = 0.0 # Strict Volatility Filter Lock

        confidence_pct = round(abs(net_score) * 100, 1)

        if is_choppy:
            bias_text, signal_type, entry_type = "CHOPPY / NO TRADE ⚠️", "NO TRADE ZONE (Low Volatility)", "Wait for Volatility Expansion"
        elif net_score >= 0.22:
            bias_text, signal_type, entry_type = "BULLISH 🟢", "STRONG BUY (CALL)", "Buy-on-Dip / Breakout Hold with Retest"
        elif net_score <= -0.22:
            bias_text, signal_type, entry_type = "BEARISH 🔴", "STRONG SELL (PUT)", "Sell-on-Rally / Breakdown Retest"
        else:
            bias_text, signal_type, entry_type = "SIDEWAYS / CONSOLIDATION 🟡", "NO TRADE / RANGE BOUND", "Wait for Level Breakout"

        atr = tech_metrics.get('atr', 15.0)
        sl_points = max(16.0, round(atr * 0.75, 2))
        t1_points = round(sl_points * 1.5, 2)
        t2_points = round(sl_points * 2.8, 2)

        if "BEARISH" in bias_text:
            entry_price, stop_loss, target_1, target_2 = live_price, live_price + sl_points, live_price - t1_points, live_price - t2_points
            invalidation_level, breakdown_level = live_price + (sl_points * 1.15), live_price - (atr * 0.4)
        elif "BULLISH" in bias_text:
            entry_price, stop_loss, target_1, target_2 = live_price, live_price - sl_points, live_price + t1_points, live_price + t2_points
            invalidation_level, breakdown_level = live_price - (sl_points * 1.15), live_price + (atr * 0.4)
        else:
            entry_price, stop_loss, target_1, target_2 = live_price, live_price - sl_points, live_price + (sl_points * 1.5), live_price - (sl_points * 1.5)
            invalidation_level, breakdown_level = live_price + (atr * 1.5), live_price + (atr * 1.0)

        return {
            'net_score': round(net_score, 2), 'confidence_pct': confidence_pct, 'bias_text': bias_text,
            'signal_type': signal_type, 'entry_type': entry_type, 'entry_price': round(entry_price, 2),
            'stop_loss': round(stop_loss, 2), 'target_1': round(target_1, 2), 'target_2': round(target_2, 2),
            'sl_points': sl_points, 't1_points': t1_points, 't2_points': t2_points,
            'invalidation_level': round(invalidation_level, 2), 'breakdown_level': round(breakdown_level, 2),
            'risk_reward_ratio': "1 : 2.5", 'tech_score': tech_score, 'smc_score': smc_score,
            'macro_score': macro_score, 'flow_score': flow_score, 'tech_metrics': tech_metrics, 
            'smc_desc': smc_desc, 'fii_footprint': fii_footprint, 'breadth_status': breadth_status, 'is_choppy': is_choppy,
            'banknifty_correlation_note': banknifty_correlation_note, 'full_breadth_status': full_breadth_status,
            'banknifty_sensex_data': banknifty_sensex_data or [],
            # NEW -- explicit setup gate. entry_price/stop_loss/target_1/target_2
            # above are ALWAYS numbers (kept for backward compatibility with
            # position-sizing/logging code that already reads them), but they
            # are NOT a genuine trade until has_setup is True. Any UI showing
            # these as an actionable signal must check this first -- this is
            # the direct fix for "trade dikhata hai har jagah / apne mann se":
            # a SIDEWAYS/CONSOLIDATION or CHOPPY read is informational only,
            # never an entry to take.
            'has_setup': bool(("BULLISH" in bias_text) or ("BEARISH" in bias_text)),
        }

    def _format_level_prediction(self, level_prediction):
        """
        NEW — purely additive helper. Formats the Early-Warning
        Support/Resistance Approach Predictor (ICT) output, if present,
        into a text block so the LLM report can synthesize/confirm it
        alongside everything else. Does not affect net_score/signal logic.
        """
        lp = level_prediction
        if not lp or lp.get('status') != 'APPROACHING_LEVEL':
            return "Not currently approaching a key support/resistance level."
        ee = lp.get('early_entry') or {}
        entry_line = "No actionable early entry yet (conviction below threshold)."
        if ee.get('entry_price') is not None:
            entry_line = (f"{ee['action']} @ ₹{ee['entry_price']:,.2f} (SL ₹{ee['stop_loss']:,.2f}, "
                           f"Target ₹{ee['target']:,.2f}), Conviction: {ee['confidence_pct']}%")
        return (
            f"Approaching {lp['level_type']} at ₹{lp['level_price']:,.2f} ({lp['distance_pts']:.1f} pts away). "
            f"Break-Through Probability: {lp['break_pct']}% | Bounce/Reject Probability: {lp['bounce_pct']}% | "
            f"Read: {lp['directional_bias']}. Confluence factors: {'; '.join(lp.get('factors', []))}. "
            f"Early Actionable Entry: {entry_line}"
        )

    def _format_level_ladder(self, level_ladder, max_each_side=4):
        """
        NEW — purely additive helper. Formats the Full Round-Number Ladder
        Calculator output (every 50/100-pt level, both directions) into a
        compact text block so the LLM report can see the WHOLE ladder, not
        just the single nearest level -- kept to the nearest few levels
        each side (not all 16) to keep the prompt short and quota-friendly.
        Does not affect net_score/signal logic.
        """
        ll = level_ladder
        if not ll or (not ll.get('supports') and not ll.get('resistances')):
            return "Ladder data not available."
        res_lines = "; ".join(
            f"₹{r['level_price']:,.2f} ({r['distance_pts']:.0f} pts away) -> Break {r['break_pct']}% / Bounce {r['bounce_pct']}%"
            for r in (ll.get('resistances') or [])[:max_each_side]
        ) or "None"
        sup_lines = "; ".join(
            f"₹{s['level_price']:,.2f} ({s['distance_pts']:.0f} pts away) -> Break {s['break_pct']}% / Bounce {s['bounce_pct']}%"
            for s in (ll.get('supports') or [])[:max_each_side]
        ) or "None"
        return f"Resistances above: {res_lines} | Supports below: {sup_lines}"

    def generate_llm_reasoning(self, live_price, meta_summary, sentiment_score, global_avg_change, use_ai=True):
        """Set use_ai=False to skip Gemini entirely and go straight to the
        deterministic template report below -- costs zero API quota, useful
        for the main dashboard's auto-refreshing report where the chat box
        is preferred for on-demand AI analysis instead."""
        m = meta_summary
        tm = m['tech_metrics']
        level_prediction_text = self._format_level_prediction(m.get('level_prediction'))
        level_ladder_text = self._format_level_ladder(m.get('level_ladder'))

        if use_ai and self.api_keys and HAS_GENAI:
            try:
                bn_lines = ""
                for idx in m.get('banknifty_sensex_data', []):
                    if idx.get('price') is not None:
                        bn_lines += f"\n- {idx['name']}: ₹{idx['price']:,.2f} ({idx['change_pct']:+.2f}%) [{idx['source']}]"
                    else:
                        bn_lines += f"\n- {idx['name']}: Unavailable"

                prompt = f"""
You are an Elite Institutional Quant Trader & Hedge Fund Lead in India analyzing Nifty 50 real-time order flow.
Write a deep, razor-sharp, highly confident institutional trade reasoning report in conversational Hinglish (Hindi + English mix).
You MUST explicitly synthesize ALL the following live parameters in your breakdown:

Live Market Data & Quant Metrics:
- Spot Price: ₹{live_price}
- Institutional Bias: {m['bias_text']} (Conviction Confidence: {m['confidence_pct']}%)
- Recommended Action: {m['signal_type']}
- Exact Entry Level: ₹{m['entry_price']}
- Stop Loss: ₹{m['stop_loss']} ({m['sl_points']} pts risk)
- Targets: T1 = ₹{m['target_1']}, T2 = ₹{m['target_2']}
- Invalidation / Cancellation Level: ₹{m['invalidation_level']}
- Technical Indicators: RSI = {tm['rsi']:.2f}, VWAP = ₹{tm['vwap']:.2f}, EMA 20 = {tm['ema_20']:.2f}, ATR = {tm['atr']:.2f}
- Derivatives & PCR: Option Chain Avg PCR = {tm['avg_pcr']:.2f}
- Smart Money Concepts (SMC): {m['smc_desc']}
- Institutional Footprint: FII Bias = {m['fii_footprint']} | Heavyweights Breadth = {m['breadth_status']}
- Full Nifty 50 Breadth (all 50 stocks): {m.get('full_breadth_status') or 'Not available'}
- Bank Nifty & Sensex (biggest cross-index movers):{bn_lines if bn_lines else ' Not available'}
- Bank Nifty ⇄ Nifty 50 Correlation: {m.get('banknifty_correlation_note') or 'Not available'}
- Volatility Status: {"Choppy / Rangebound (No Trade Guard Active)" if m['is_choppy'] else "Active Volatility Expansion"}
- Global Macro: Avg Change = {global_avg_change}% | Sentiment = {sentiment_score}
- Early-Warning Support/Resistance Approach Predictor (ICT): {level_prediction_text}
- Full Round-Number Ladder (nearest levels each side, every 50/100pt, Break%/Bounce% each): {level_ladder_text}

Mandatory Tone & Structure:
1. Start exact tone: "Haan. Maine chart + options chain + FII footprint + internal breadth + Bank Nifty/Sensex correlation + global news data sab read kar liya hai..."
2. Explicitly analyze how FII data, full Nifty 50 breadth, heavyweights, AND the Bank Nifty/Sensex correlation align or conflict with the technical price action.
3. If there is a Bank Nifty divergence warning, call it out clearly as a fake breakout/breakdown risk.
4. Clearly mention the exact entry trigger, fake breakout warning, and strict invalidation rule to protect capital.
5. Explicitly confirm whether the Early-Warning Support/Resistance Approach Predictor (ICT) agrees or disagrees with the main confluence bias above -- if it disagrees, call that out as a conflicting signal to watch, don't silently ignore it.
NO financial disclaimers. Make it read like a professional desk note from a top proprietary trading desk.
"""
                last_exc = None
                for key in self.api_keys:
                    try:
                        client = genai.Client(api_key=key)
                        response = client.models.generate_content(
                            model='gemini-3.1-flash-lite',
                            contents=prompt
                        )
                        return response.text
                    except Exception as e:
                        logger.exception("Broad exception caught; fallback path executed")
                        last_exc = e
                        if _is_quota_error(e):
                            continue  # this key's limit is over -- try the next one
                        break  # a non-quota error -- another key won't fix it, fall through to the static report
            except Exception as e:
                logger.exception("Broad exception caught; fallback path executed")
                pass 

        # Professional Quant Fallback Report
        bn_text = ""
        for idx in m.get('banknifty_sensex_data', []):
            if idx.get('price') is not None:
                bn_text += f"\n* **{idx['name']}:** ₹{idx['price']:,.2f} ({idx['change_pct']:+.2f}%) — {idx['source']}"
            else:
                bn_text += f"\n* **{idx['name']}:** Unavailable"

        return f"""
### 🦅 Institutional Quant AI Deep Reasoning & Execution Plan

**Haan. Maine chart + Options Chain + FII Footprint + Internal Breadth + Bank Nifty/Sensex Correlation + SMC Order Blocks + Global News data sab read kar liya hai.**
Nifty Spot **₹{live_price:,.2f}** par trade kar raha hai. VWAP: **₹{tm['vwap']:,.2f}** | EMA 20: **₹{tm['ema_20']:,.2f}** | RSI: **{tm['rsi']:.2f}** | PCR: **{tm['avg_pcr']:.2f}** | FII Footprint: **{m['fii_footprint']}**.

---

### 📊 Model Decision: **{m['bias_text']}** (Confidence Score: {m['confidence_pct']}%)

#### 🎯 Primary Execution Plan:
* **Actionable Setup:** {m['signal_type']}
* **Execution Strategy:** {m['entry_type']} at **₹{m['entry_price']:,.2f}**
* **Stop Loss (SL):** **₹{m['stop_loss']:,.2f}** (Risk: {m['sl_points']} pts)
* **Target 1 (T1):** **₹{m['target_1']:,.2f}**
* **Target 2 (T2):** **₹{m['target_2']:,.2f}**
* **Risk-to-Reward:** {m['risk_reward_ratio']}

---

### 🧠 Multi-Factor Confluence Breakdown:
1. **FII / DII Footprint & Heavyweights Breadth:** FII bias is **{m['fii_footprint']}** and heavyweights breadth is **{m['breadth_status']}**.
2. **Full Nifty 50 Breadth (all 50 stocks):** {m.get('full_breadth_status') or 'Not available'}.
3. **Bank Nifty & Sensex:**{bn_text if bn_text else ' Not available'}
   Correlation Check: **{m.get('banknifty_correlation_note') or 'Not available'}**
4. **Smart Money Structure:** Current SMC Event = **"{m['smc_desc']}"** with Volatility State: {"Choppy ⚠️" if m['is_choppy'] else "Active 🟢"}.
5. **Global Macro Context:** Global sentiment is **{sentiment_score}** with an average change of **{global_avg_change}%**.
6. **Early-Warning Support/Resistance Approach Predictor (ICT):** {level_prediction_text}
7. **Full Round-Number Ladder (every 50/100pt level, both directions):** {level_ladder_text}

⚠️ **Trap Warning & Confirmation Rule:**
Do not enter blindly on a direct touch. Wait for a candle confirmation close near **₹{m['entry_price']:,.2f}** followed by a valid retest before executing.
{"🚨 **Bank Nifty divergence detected — extra caution advised, elevated fake-breakout risk.**" if m.get('banknifty_correlation_note') and 'DIVERGENCE' in str(m.get('banknifty_correlation_note')).upper() else ""}

🛑 **Invalidation Rule:**
Agar price **₹{m['invalidation_level']:,.2f}** ke opposite side sustain kar jata hai, toh ye poora setup cancel ho jayega aur position immediate cut karni hai.
"""
