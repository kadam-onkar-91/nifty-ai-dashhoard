from app_logging import get_logger
logger = get_logger(__name__)
import requests
import time

class AlertManager:
    def __init__(self, bot_token, chat_id):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.last_alert_time = 0
        self.cooldown_period = 300  # 5 minutes cooldown to avoid spam

    def send_trade_alert(self, signal_type, confidence, price, sentiment, logic):
        # Cooldown check
        current_time = time.time()
        if (current_time - self.last_alert_time) < self.cooldown_period:
            return False

        # Professional Message Formatting
        message = (
            f"🔔 *TRADE ALERT: {signal_type.upper()}*\n\n"
            f"💰 *Price:* ₹{price}\n"
            f"🎯 *Confidence:* {confidence}%\n"
            f"📊 *Sentiment:* {sentiment}\n"
            f"🧠 *Logic:* {logic}\n\n"
            f"🚀 _Institutional AI Engine_"
        )

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "Markdown"
        }

        try:
            response = requests.post(url, data=payload, timeout=10)
            if response.status_code == 200:
                self.last_alert_time = current_time
                return True
            else:
                print(f"Failed to send alert: {response.text}")
                return False
        except Exception as e:
            logger.exception("Broad exception caught; fallback path executed")
            print(f"Error sending Telegram alert: {e}")
            return False

    # =====================================================================
    # RE-ADDED — these two methods were missing from this deployed copy,
    # even though app.py already calls evaluate_and_send_confluence_alert()
    # every refresh -- that mismatch is exactly what caused the
    # AttributeError. Nothing above this line was touched.
    # =====================================================================
    def send_full_confluence_alert(self, direction, price, main_confidence, ml_confidence,
                                    level_price, level_pct, level_read, oi_note,
                                    banknifty_note, global_note=None, breadth_note=None,
                                    min_level_pct=65.0):
        if not direction or direction not in ("BUY", "SELL"):
            return False
        if main_confidence is None or main_confidence < 55:
            return False
        if ml_confidence is None:
            return False
        if level_pct is None or level_pct < min_level_pct:
            return False
        if banknifty_note and "DIVERGENCE WARNING" in banknifty_note.upper():
            return False

        message = (
            f"🚨 *FULL CONFLUENCE ALERT: {direction}*\n\n"
            f"💰 *Price:* ₹{price:,.2f}\n"
            f"🎯 *Main Signal Confidence:* {main_confidence}%\n"
            f"🤖 *ML Model Confidence:* {ml_confidence}%\n"
            f"📐 *Nearest Level:* ₹{level_price:,.2f} → {level_read} ({level_pct}%)\n"
            f"📊 *OI/PCR:* {oi_note}\n"
            f"🏦 *Bank Nifty:* {banknifty_note or 'No divergence flagged'}\n"
            + (f"🌍 *Global:* {global_note}\n" if global_note else "")
            + (f"📈 *Breadth:* {breadth_note}\n" if breadth_note else "")
            + f"\n✅ _All checklist conditions aligned right now — verify before acting, this is not a guarantee._"
        )

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": "Markdown"}
        try:
            response = requests.post(url, data=payload, timeout=10)
            if response.status_code == 200:
                return True
            else:
                print(f"Failed to send full confluence alert: {response.text}")
                return False
        except Exception as e:
            logger.exception("Broad exception caught; fallback path executed")
            print(f"Error sending Telegram full confluence alert: {e}")
            return False

    def evaluate_and_send_confluence_alert(self, direction, price, main_confidence, ml_confidence,
                                            level_price, level_pct, level_read, oi_note,
                                            banknifty_note, global_note=None, breadth_note=None,
                                            min_level_pct_full=65.0, min_level_pct_partial=55.0):
        if not direction or direction not in ("BUY", "SELL"):
            return False, None

        checks_met = 0
        if main_confidence is not None and main_confidence >= 55:
            checks_met += 1
        if ml_confidence is not None:
            checks_met += 1
        level_ok_full = level_pct is not None and level_pct >= min_level_pct_full
        level_ok_partial = level_pct is not None and level_pct >= min_level_pct_partial
        if level_ok_partial:
            checks_met += 1
        banknifty_ok = not (banknifty_note and "DIVERGENCE WARNING" in banknifty_note.upper())
        if banknifty_ok:
            checks_met += 1

        if checks_met >= 4 and level_ok_full:
            tier, emoji, label = "FULL", "🚨", "FULL CONFLUENCE ALERT"
        elif checks_met >= 3:
            tier, emoji, label = "STRONG", "⚡", "STRONG SETUP ALERT"
        else:
            return False, None

        message = (
            f"{emoji} *{label}: {direction}* ({checks_met}/4 checklist items met)\n\n"
            f"💰 *Price:* ₹{price:,.2f}\n"
            f"🎯 *Main Signal Confidence:* {main_confidence}%\n"
            f"🤖 *ML Model:* {f'{ml_confidence}% agrees' if ml_confidence is not None else 'Disagrees / no confident read'}\n"
            f"📐 *Nearest Level:* ₹{level_price:,.2f} → {level_read} ({level_pct}%)\n"
            f"📊 *OI/PCR:* {oi_note}\n"
            f"🏦 *Bank Nifty:* {banknifty_note or 'No divergence flagged'}\n"
            + (f"🌍 *Global:* {global_note}\n" if global_note else "")
            + (f"📈 *Breadth:* {breadth_note}\n" if breadth_note else "")
            + (
                "\n✅ _All 4 checklist conditions aligned — the higher-quality setup. Still not a guarantee._"
                if tier == "FULL" else
                "\n⚠️ _Most (not all) conditions aligned — decent setup but treat with extra caution. Still not a guarantee._"
            )
        )

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": "Markdown"}
        try:
            response = requests.post(url, data=payload, timeout=10)
            if response.status_code == 200:
                return True, tier
            else:
                print(f"Failed to send confluence alert: {response.text}")
                return False, None
        except Exception as e:
            logger.exception("Broad exception caught; fallback path executed")
            print(f"Error sending Telegram confluence alert: {e}")
            return False, None
